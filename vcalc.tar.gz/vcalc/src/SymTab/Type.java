package SymTab;

public interface Type {
	public String getName();
}
