vcalc
=====

```
Lyle: I'm going to use this file as a central location to share what I'm currently doing,
 what my plan is for the immediate future, and most importantly, what files I am actively editing
 to help avoid merge conflicts. (Plus helps keep my brain from wandering all over the place)

Lyle's development schedule and status:
	ETS: Estimated Time to Start
	ETC: Estimated Time to Completion
	
	Error Reporting: 1st pass complete (See PopulateST.g for further). 
		TO-DO: look into "proper" way of reporting errors as discussed in class.
			Priority: Moderate
			ETS: early next week
			ETC: early next week
	Interpretor: all but validity checking is functional. 
		TO-DO: Complete support class(es).
			Priority: High
			ETS: Saturday morning (started)
			ETC: lock step with interpreter
		TO-DO: Complete interpretor grammar (validity checking left)
			Priority: High
			ETS: Saturday morning/early afternoon (started)
			ETC: Monday
		TO-DO: Find better way to do conditional execution for if/loop statements
			Priority: Low
			ETS: early/mid next week (pending progress as of Monday lab)
			ETC: unknown

	Active Files:
		none
	```
